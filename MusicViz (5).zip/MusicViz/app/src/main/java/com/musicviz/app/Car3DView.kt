package com.musicviz.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import com.musicviz.engine.Scene3D

/** 3D-машина: рисуется программно в фоновом потоке, вращается пальцем, масштаб щипком. */
class Car3DView(context: Context) : View(context) {

    val scene = Scene3D()
    @Volatile var sensitivity = 1f
    @Volatile var quality = 1
    @Volatile var autoRotate = true
    var onTap: (() -> Unit)? = null

    private var bmp: Bitmap? = null
    private val lock = Any()
    private val dst = Rect()
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    @Volatile private var running = false
    private var thread: Thread? = null
    @Volatile private var lastTouch = 0L
    private var lastX = 0f
    private var lastY = 0f

    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            scene.dist = (scene.dist / d.scaleFactor).coerceIn(3.2f, 12f)
            return true
        }
    })

    private val tapDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onSingleTapUp(e: MotionEvent): Boolean {
            onTap?.invoke()
            return true
        }
    })

    fun setModel(i: Int) {
        synchronized(scene) { scene.setModel(i) }
    }

    fun resetView() {
        scene.yaw = Math.PI.toFloat() + 0.62f
        scene.pitch = 0.30f
        scene.dist = 6.4f
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        running = true
        thread = Thread { loop() }.also {
            it.isDaemon = true
            it.start()
        }
    }

    override fun onDetachedFromWindow() {
        running = false
        thread?.interrupt()
        thread = null
        super.onDetachedFromWindow()
    }

    private fun loop() {
        var last = System.nanoTime()
        var pixels = IntArray(0)
        try {
            while (running) {
                val t0 = System.nanoTime()
                val vw = width
                val vh = height
                if (vw <= 0 || vh <= 0) {
                    Thread.sleep(50)
                    continue
                }
                val longSide = when (quality) { 0 -> 360; 1 -> 480; else -> 600 }
                val aspect = vw.toFloat() / vh
                val w = if (aspect >= 1f) longSide else maxOf(120, (longSide * aspect).toInt())
                val h = if (aspect >= 1f) maxOf(120, (longSide / aspect).toInt()) else longSide
                if (pixels.size != w * h) pixels = IntArray(w * h)

                val dt = ((t0 - last) / 1e9f).coerceIn(0.001f, 0.05f)
                last = t0
                synchronized(scene) {
                    if (AudioBus.running) scene.step(dt, AudioBus.bass, AudioBus.bands, sensitivity)
                    else scene.stepDemo(dt)
                    if (autoRotate && System.currentTimeMillis() - lastTouch > 2500) scene.yaw += dt * 0.35f
                    scene.render(pixels, w, h, 2, false)
                }
                synchronized(lock) {
                    var b = bmp
                    if (b == null || b.width != w || b.height != h) {
                        b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        bmp = b
                    }
                    b!!.setPixels(pixels, 0, w, 0, 0, w, h)
                }
                postInvalidateOnAnimation()
                val spent = (System.nanoTime() - t0) / 1_000_000
                if (spent < 30) Thread.sleep(30 - spent)
            }
        } catch (e: InterruptedException) {
        }
    }

    override fun onDraw(c: Canvas) {
        synchronized(lock) {
            val b = bmp ?: return
            dst.set(0, 0, width, height)
            c.drawBitmap(b, null, dst, paint)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        tapDetector.onTouchEvent(e)
        scaleDetector.onTouchEvent(e)
        lastTouch = System.currentTimeMillis()
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = e.x
                lastY = e.y
            }
            MotionEvent.ACTION_MOVE -> {
                if (e.pointerCount == 1 && !scaleDetector.isInProgress) {
                    scene.yaw -= (e.x - lastX) * 0.008f
                    scene.pitch = (scene.pitch + (e.y - lastY) * 0.006f).coerceIn(0.03f, 1.25f)
                }
                lastX = e.x
                lastY = e.y
            }
            MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_POINTER_DOWN -> {
                lastX = e.x
                lastY = e.y
            }
        }
        return true
    }
}
