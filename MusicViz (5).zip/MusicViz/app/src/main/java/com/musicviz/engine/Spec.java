package com.musicviz.engine;

/** Описание модели ВАЗ: сечения кузова вдоль оси z (сзади -> спереди). */
final class Spec {
    String name;
    boolean hatch;
    float[] zs;
    float[][] hw = new float[7][], yy = new float[7][];
    float[][] doors;                  // {zRear, zFront}, первая — передняя дверь
    float zRoofRear, zRoofFront, zCowl, zHinge;
    float wheelZF = 1.246f, wheelZR = -1.246f, wheelX = 0.715f;
    float sill;                       // нижняя кромка проёма (хэтчбек)
    float cargoFloor;
    float[] headX, headY, tailX, tailY;   // {x0,x1}, {y0,y1}
    String plate;
    boolean roundHeads;

    float zRear() { return zs[0]; }
    float zFront() { return zs[zs.length - 1]; }

    float[] pt(int k, float z) {
        return new float[]{ Sp.eval(zs, hw[k], z), Sp.eval(zs, yy[k], z) };
    }

    /** Точка профиля при параметре s в [0,6] (Catmull-Rom по 7 точкам). */
    float[] prof(float z, float s) {
        float[][] P = new float[7][];
        for (int k = 0; k < 7; k++) P[k] = pt(k, z);
        int seg = Math.min((int) s, 5);
        float u = s - seg, u2 = u * u, u3 = u2 * u;
        float[] p0 = P[Math.max(seg - 1, 0)], p1 = P[seg], p2 = P[seg + 1], p3 = P[Math.min(seg + 2, 6)];
        float[] r = new float[2];
        for (int c = 0; c < 2; c++)
            r[c] = 0.5f * ((2 * p1[c]) + (-p0[c] + p2[c]) * u + (2*p0[c] - 5*p1[c] + 4*p2[c] - p3[c]) * u2
                    + (-p0[c] + 3*p1[c] - 3*p2[c] + p3[c]) * u3);
        return r;
    }

    static float[] a(float... v) { return v; }

    static Spec sedan2110() {
        Spec s = new Spec();
        s.name = "ВАЗ-2110";
        s.zs = a(-2.13f,-2.00f,-1.55f,-1.15f,-0.55f,0.25f,0.78f,1.40f,2.00f,2.13f);
        s.hw[0] = a(0.60f,0.66f,0.69f,0.70f,0.70f,0.70f,0.70f,0.69f,0.64f,0.58f);
        s.yy[0] = a(0.30f,0.26f,0.22f,0.21f,0.20f,0.20f,0.20f,0.21f,0.27f,0.30f);
        s.hw[1] = a(0.70f,0.76f,0.80f,0.81f,0.81f,0.81f,0.81f,0.80f,0.76f,0.68f);
        s.yy[1] = a(0.42f,0.40f,0.40f,0.40f,0.40f,0.40f,0.40f,0.40f,0.40f,0.42f);
        s.hw[2] = a(0.74f,0.81f,0.835f,0.84f,0.84f,0.84f,0.84f,0.83f,0.80f,0.72f);
        s.yy[2] = a(0.62f,0.64f,0.66f,0.68f,0.70f,0.70f,0.70f,0.68f,0.62f,0.60f);
        s.hw[3] = a(0.72f,0.79f,0.82f,0.82f,0.82f,0.82f,0.80f,0.80f,0.77f,0.70f);
        s.yy[3] = a(0.86f,0.94f,0.97f,0.975f,0.98f,0.98f,0.97f,0.90f,0.80f,0.72f);
        s.hw[4] = a(0.70f,0.76f,0.78f,0.76f,0.64f,0.64f,0.74f,0.74f,0.72f,0.66f);
        s.yy[4] = a(0.89f,0.965f,0.975f,0.985f,1.38f,1.395f,0.975f,0.915f,0.815f,0.735f);
        s.hw[5] = a(0.52f,0.60f,0.62f,0.62f,0.52f,0.52f,0.62f,0.60f,0.54f,0.48f);
        s.yy[5] = a(0.90f,0.975f,0.985f,0.99f,1.40f,1.41f,0.98f,0.925f,0.825f,0.745f);
        s.hw[6] = new float[10];
        s.yy[6] = a(0.90f,0.98f,0.99f,0.995f,1.41f,1.42f,0.99f,0.93f,0.83f,0.75f);
        s.doors = new float[][]{{-0.02f,0.66f},{-0.95f,-0.06f}};
        s.zRoofRear = -0.55f; s.zRoofFront = 0.25f; s.zCowl = 0.78f; s.zHinge = -1.15f;
        s.cargoFloor = 0.40f;
        s.headX = a(0.30f,0.70f); s.headY = a(0.58f,0.70f);
        s.tailX = a(0.28f,0.68f); s.tailY = a(0.64f,0.82f);
        s.plate = "А110ВС47";
        return s;
    }

    static Spec sedan2107() {
        Spec s = new Spec();
        s.name = "ВАЗ-2107";
        s.zs = a(-2.07f,-1.95f,-1.50f,-1.00f,-0.50f,0.15f,0.55f,1.15f,1.95f,2.07f);
        s.hw[0] = a(0.62f,0.66f,0.69f,0.70f,0.70f,0.70f,0.70f,0.69f,0.65f,0.60f);
        s.yy[0] = a(0.30f,0.26f,0.24f,0.23f,0.22f,0.22f,0.22f,0.23f,0.27f,0.30f);
        s.hw[1] = a(0.70f,0.77f,0.80f,0.80f,0.80f,0.80f,0.80f,0.80f,0.77f,0.70f);
        s.yy[1] = a(0.45f,0.42f,0.42f,0.42f,0.42f,0.42f,0.42f,0.42f,0.42f,0.45f);
        s.hw[2] = a(0.74f,0.80f,0.81f,0.81f,0.81f,0.81f,0.81f,0.81f,0.79f,0.73f);
        s.yy[2] = a(0.66f,0.68f,0.70f,0.72f,0.74f,0.74f,0.74f,0.72f,0.66f,0.64f);
        s.hw[3] = a(0.73f,0.79f,0.80f,0.80f,0.80f,0.80f,0.80f,0.80f,0.77f,0.71f);
        s.yy[3] = a(0.90f,0.98f,1.00f,1.01f,1.02f,1.02f,1.00f,0.95f,0.86f,0.76f);
        s.hw[4] = a(0.71f,0.76f,0.77f,0.75f,0.68f,0.68f,0.74f,0.75f,0.73f,0.67f);
        s.yy[4] = a(0.92f,0.99f,1.01f,1.02f,1.40f,1.41f,1.01f,0.96f,0.87f,0.77f);
        s.hw[5] = a(0.55f,0.62f,0.64f,0.63f,0.57f,0.57f,0.64f,0.62f,0.55f,0.49f);
        s.yy[5] = a(0.93f,1.00f,1.02f,1.03f,1.42f,1.43f,1.02f,0.97f,0.88f,0.78f);
        s.hw[6] = new float[10];
        s.yy[6] = a(0.93f,1.00f,1.02f,1.03f,1.43f,1.44f,1.03f,0.98f,0.89f,0.79f);
        s.doors = new float[][]{{-0.05f,0.58f},{-0.92f,-0.09f}};
        s.zRoofRear = -0.50f; s.zRoofFront = 0.15f; s.zCowl = 0.55f; s.zHinge = -1.00f;
        s.wheelZF = 1.21f; s.wheelZR = -1.21f; s.wheelX = 0.70f;
        s.cargoFloor = 0.42f;
        s.headX = a(0.30f,0.66f); s.headY = a(0.62f,0.74f);
        s.tailX = a(0.30f,0.66f); s.tailY = a(0.66f,0.84f);
        s.roundHeads = true;
        s.plate = "А107ВС63";
        return s;
    }

    static Spec hatch2114() {
        Spec s = new Spec();
        s.name = "ВАЗ-2114";
        s.hatch = true;
        s.zs = a(-2.00f,-1.92f,-1.75f,-1.40f,-0.60f,0.25f,0.75f,1.38f,1.98f,2.06f);
        s.hw[0] = a(0.60f,0.64f,0.67f,0.69f,0.70f,0.70f,0.70f,0.69f,0.64f,0.58f);
        s.yy[0] = a(0.32f,0.30f,0.27f,0.23f,0.21f,0.21f,0.21f,0.22f,0.28f,0.31f);
        s.hw[1] = a(0.70f,0.75f,0.78f,0.80f,0.81f,0.81f,0.81f,0.80f,0.76f,0.68f);
        s.yy[1] = a(0.45f,0.44f,0.43f,0.42f,0.42f,0.42f,0.42f,0.42f,0.42f,0.44f);
        s.hw[2] = a(0.73f,0.79f,0.81f,0.82f,0.83f,0.83f,0.83f,0.82f,0.79f,0.72f);
        s.yy[2] = a(0.66f,0.68f,0.70f,0.72f,0.72f,0.72f,0.72f,0.70f,0.64f,0.62f);
        s.hw[3] = a(0.72f,0.77f,0.80f,0.80f,0.80f,0.80f,0.79f,0.79f,0.76f,0.70f);
        s.yy[3] = a(0.84f,0.92f,0.99f,1.00f,1.00f,1.00f,0.98f,0.90f,0.80f,0.72f);
        s.hw[4] = a(0.69f,0.73f,0.74f,0.69f,0.66f,0.66f,0.74f,0.74f,0.71f,0.65f);
        s.yy[4] = a(0.86f,0.94f,1.10f,1.42f,1.43f,1.43f,0.975f,0.915f,0.82f,0.735f);
        s.hw[5] = a(0.50f,0.56f,0.58f,0.56f,0.54f,0.54f,0.62f,0.60f,0.54f,0.48f);
        s.yy[5] = a(0.89f,0.96f,1.13f,1.45f,1.46f,1.46f,0.98f,0.92f,0.82f,0.74f);
        s.hw[6] = new float[10];
        s.yy[6] = a(0.90f,0.97f,1.14f,1.465f,1.47f,1.47f,0.99f,0.93f,0.83f,0.75f);
        s.doors = new float[][]{{-0.02f,0.68f},{-0.98f,-0.06f}};
        s.zRoofRear = -1.40f; s.zRoofFront = 0.25f; s.zCowl = 0.75f; s.zHinge = -1.40f;
        s.sill = 0.80f; s.cargoFloor = 0.66f;
        s.headX = a(0.34f,0.70f); s.headY = a(0.58f,0.70f);
        s.tailX = a(0.26f,0.70f); s.tailY = a(0.56f,0.78f);
        s.plate = "К633ТК26";
        return s;
    }

    static Spec hatch2112() {
        Spec b = sedan2110();
        Spec s = new Spec();
        s.name = "ВАЗ-2112";
        s.hatch = true;
        s.zs = a(-2.05f,-1.96f,-1.72f,-1.25f,-0.55f,0.25f,0.78f,1.40f,2.05f,2.17f);
        float[][] rearHW = {
            {0.60f,0.65f,0.68f,0.70f}, {0.70f,0.76f,0.79f,0.81f}, {0.73f,0.80f,0.83f,0.84f},
            {0.72f,0.78f,0.81f,0.82f}, {0.69f,0.73f,0.74f,0.66f}, {0.50f,0.56f,0.58f,0.54f}, {0,0,0,0}};
        float[][] rearYY = {
            {0.31f,0.29f,0.24f,0.21f}, {0.44f,0.43f,0.42f,0.41f}, {0.64f,0.66f,0.69f,0.70f},
            {0.84f,0.93f,0.98f,0.985f}, {0.86f,0.95f,1.08f,1.40f}, {0.89f,0.97f,1.11f,1.415f}, {0.90f,0.98f,1.12f,1.425f}};
        for (int k = 0; k < 7; k++) {
            s.hw[k] = new float[10]; s.yy[k] = new float[10];
            for (int i = 0; i < 4; i++) { s.hw[k][i] = rearHW[k][i]; s.yy[k][i] = rearYY[k][i]; }
            for (int i = 4; i < 10; i++) { s.hw[k][i] = b.hw[k][i]; s.yy[k][i] = b.yy[k][i]; }
        }
        s.doors = new float[][]{{-0.02f,0.66f},{-0.98f,-0.06f}};
        s.zRoofRear = -0.55f; s.zRoofFront = 0.25f; s.zCowl = 0.78f; s.zHinge = -1.25f;
        s.sill = 0.80f; s.cargoFloor = 0.66f;
        s.headX = a(0.30f,0.70f); s.headY = a(0.58f,0.70f);
        s.tailX = a(0.26f,0.70f); s.tailY = a(0.58f,0.80f);
        s.plate = "Х112ХХ78";
        return s;
    }

    static Spec[] all() { return new Spec[]{ sedan2110(), hatch2114(), hatch2112(), sedan2107() }; }
}
