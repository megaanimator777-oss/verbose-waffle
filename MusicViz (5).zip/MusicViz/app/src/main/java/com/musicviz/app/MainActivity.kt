package com.musicviz.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import com.musicviz.engine.Scene3D
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var root: LinearLayout
    private lateinit var car: Car3DView
    private lateinit var panel: ScrollView
    private lateinit var startBtn: Button
    private lateinit var status: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var panelVisible = true
    private var hintShown = false

    private val accents = intArrayOf(
        0xFF00B0FF.toInt(), 0xFFFF1744.toInt(), 0xFF00E676.toInt(),
        0xFFD500F9.toInt(), 0xFFFFEA00.toInt(), 0xFFFFFFFF.toInt()
    )

    private val ticker = object : Runnable {
        override fun run() {
            refreshStatus()
            handler.postDelayed(this, 600)
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs.get(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        root = LinearLayout(this)
        root.setBackgroundColor(0xFF05060B.toInt())

        car = Car3DView(this)
        SceneConfig.apply(car.scene, prefs, false)
        car.sensitivity = prefs.getInt(Prefs.SENS, 100) / 100f
        car.quality = prefs.getInt(Prefs.QUALITY, 1)
        car.autoRotate = prefs.getBoolean(Prefs.AUTOROT, true)
        car.onTap = { runOnUiThread { togglePanel() } }

        panel = ScrollView(this)
        panel.setBackgroundColor(0xFF0B0D14.toInt())
        panel.addView(buildPanel())

        root.addView(car)
        root.addView(panel)
        applyOrientation()
        setContentView(root)

        if (intent.getBooleanExtra("autostart", false)) handler.post { onStartClicked() }
    }

    private fun applyOrientation() {
        val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        if (land) {
            root.orientation = LinearLayout.HORIZONTAL
            car.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.4f)
            panel.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
        } else {
            root.orientation = LinearLayout.VERTICAL
            car.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            panel.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1.25f)
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applyOrientation()
    }

    // ---------- Панель настроек ----------

    private fun buildPanel(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        // большой нижний отступ: ползунки не прячутся под системной навигацией
        col.setPadding(dp(16), dp(12), dp(16), dp(180))

        status = TextView(this)
        status.setTextColor(0xFFB0B6C3.toInt())
        status.textSize = 13f
        col.addView(status)

        startBtn = Button(this)
        startBtn.textSize = 16f
        startBtn.setOnClickListener { onStartClicked() }
        col.addView(startBtn, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))

        // --- звук саба (ползунки наверху, чтобы до них было легко дотянуться) ---
        col.addView(header("Звук: саб в багажнике"))
        col.addView(toggle("Включить обработку звука", Prefs.SUB_ON, false) { v ->
            if (v && !AudioBus.running) {
                Toast.makeText(this, "Нажми «Старт», чтобы эффект заработал", Toast.LENGTH_LONG).show()
            }
        })
        col.addView(seek("Мощность баса", Prefs.POWER, 100, 85) { })
        col.addView(seek("Глухота (как из багажника)", Prefs.MUFFLE, 100, 55) { })
        col.addView(seek("Усиление громкости", Prefs.GAIN, 100, 40) { })
        val testBtn = Button(this)
        testBtn.text = "Проверить бас (тестовый бит)"
        testBtn.setOnClickListener { playTest() }
        col.addView(testBtn)
        col.addView(note("Эффект меняет звук всех плееров сразу, пока приложение запущено. Включай и выключай переключатель во время «теста» — разница слышна сразу. На динамике телефона глубокого баса не будет, лучше наушники или колонка. Не ставь максимум баса на большой громкости."))

        // --- действия с машиной ---
        col.addView(header("Машина"))
        col.addView(toggle("Двери открыты", Prefs.DOORS, false) { v -> car.scene.doorsOpen = v })
        col.addView(toggle("Багажник / задняя дверь открыты", Prefs.TRUNK, true) { v -> car.scene.trunkOpen = v })
        col.addView(toggle("Фары включены", Prefs.HEAD, false) { v -> car.scene.headlights = v })
        col.addView(toggle("Свет в салоне", Prefs.CABIN, false) { v -> car.scene.cabinLight = v })

        col.addView(label("Модель"))
        val models = Scene3D.modelNames()
        col.addView(spinner(models.toList(), prefs.getInt(Prefs.MODEL, 1)) { i ->
            prefs.edit().putInt(Prefs.MODEL, i).apply()
            if (car.scene.modelIdx != i) car.setModel(i)
        })
        col.addView(label("Цвет кузова"))
        col.addView(spinner(Scene3D.paintNames().toList(), prefs.getInt(Prefs.PAINT, 2)) { i ->
            prefs.edit().putInt(Prefs.PAINT, i).apply()
            car.scene.setPaint(i)
        })
        col.addView(label("Цвет подсветки"))
        col.addView(swatches())

        val resetBtn = Button(this)
        resetBtn.text = "Сбросить вид (сзади, как на фото)"
        resetBtn.setOnClickListener { car.resetView() }
        col.addView(resetBtn)

        // --- визуализация ---
        col.addView(header("Визуализация"))
        col.addView(seek("Чувствительность", Prefs.SENS, 250, 100) { v -> car.sensitivity = v / 100f })
        col.addView(toggle("Эквалайзер вокруг машины", Prefs.BARS, true) { v -> car.scene.showBars = v })
        col.addView(toggle("Автовращение", Prefs.AUTOROT, true) { v -> car.autoRotate = v })
        col.addView(label("Качество 3D"))
        col.addView(radios(listOf("Лёгкое", "Среднее", "Высокое"), prefs.getInt(Prefs.QUALITY, 1), true) { i ->
            prefs.edit().putInt(Prefs.QUALITY, i).apply()
            car.quality = i
        })

        col.addView(header("Как слушать звук"))
        col.addView(radios(
            listOf("Системный микшер (по умолчанию)", "Запись воспроизведения (Android 10+)"),
            prefs.getInt(Prefs.METHOD, 0), false
        ) { i ->
            prefs.edit().putInt(Prefs.METHOD, i).apply()
            if (AudioBus.running) {
                stopService(Intent(this, AudioService::class.java))
                handler.postDelayed({ beginCapture() }, 500)
            }
        })
        col.addView(note("Если музыка играет, а машина стоит на месте — переключи на второй способ."))
        col.addView(note("Виджет: добавь «MusicViz» на рабочий стол. Нажатие на виджет запускает и останавливает музыкальную анимацию. Крути машину пальцем, щипком меняй масштаб, нажми на неё — настройки скроются."))
        return col
    }

    private fun header(text: String): TextView {
        val t = TextView(this)
        t.text = text.uppercase()
        t.setTextColor(0xFF7FD6FF.toInt())
        t.textSize = 12f
        t.typeface = Typeface.DEFAULT_BOLD
        t.setPadding(0, dp(20), 0, dp(6))
        return t
    }

    private fun label(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextColor(Color.WHITE)
        t.textSize = 14f
        t.setPadding(0, dp(10), 0, dp(2))
        return t
    }

    private fun note(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextColor(0xFF8A90A0.toInt())
        t.textSize = 12f
        t.setPadding(0, dp(6), 0, dp(2))
        return t
    }

    private fun seek(title: String, key: String, max: Int, def: Int, onChange: (Int) -> Unit): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(0, dp(6), 0, dp(6))
        val label = TextView(this)
        label.setTextColor(Color.WHITE)
        label.textSize = 14f
        val bar = SeekBar(this)
        bar.max = max
        bar.progress = prefs.getInt(key, def)
        bar.setPadding(dp(14), dp(14), dp(14), dp(14))
        label.text = "$title: ${bar.progress}"
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                label.text = "$title: $p"
                if (fromUser) {
                    prefs.edit().putInt(key, p).apply()
                    onChange(p)
                }
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        // ползунок не «отдаёт» жест прокрутке и системной навигации
        bar.setOnTouchListener { v, _ ->
            v.parent.requestDisallowInterceptTouchEvent(true)
            false
        }
        bar.addOnLayoutChangeListener { v, l, t, r, b, _, _, _, _ ->
            if (Build.VERSION.SDK_INT >= 29) v.systemGestureExclusionRects = listOf(Rect(0, 0, r - l, b - t))
        }
        box.addView(label)
        box.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)))
        return box
    }

    private fun toggle(title: String, key: String, def: Boolean, onChange: (Boolean) -> Unit): Switch {
        val sw = Switch(this)
        sw.text = title
        sw.setTextColor(Color.WHITE)
        sw.textSize = 14f
        sw.setPadding(0, dp(10), 0, dp(10))
        sw.isChecked = prefs.getBoolean(key, def)
        sw.setOnCheckedChangeListener { _, v ->
            prefs.edit().putBoolean(key, v).apply()
            onChange(v)
        }
        return sw
    }

    private fun spinner(items: List<String>, selected: Int, onSelect: (Int) -> Unit): Spinner {
        val sp = Spinner(this)
        val ad = ArrayAdapter(this, android.R.layout.simple_spinner_item, items)
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        sp.adapter = ad
        sp.setSelection(selected.coerceIn(0, items.size - 1), false)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { onSelect(pos) }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        return sp
    }

    private fun radios(options: List<String>, selected: Int, horizontal: Boolean, onSelect: (Int) -> Unit): RadioGroup {
        val g = RadioGroup(this)
        g.orientation = if (horizontal) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
        options.forEachIndexed { i, t ->
            val rb = RadioButton(this)
            rb.id = View.generateViewId()
            rb.text = t
            rb.setTextColor(Color.WHITE)
            rb.textSize = 14f
            g.addView(rb)
            if (i == selected) rb.isChecked = true
        }
        g.setOnCheckedChangeListener { grp, checkedId ->
            onSelect(grp.indexOfChild(grp.findViewById(checkedId)))
        }
        return g
    }

    private fun swatches(): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(0, dp(6), 0, dp(6))
        val items = ArrayList<Pair<View, Int>>()
        fun refresh() {
            val cur = prefs.getInt(Prefs.ACCENT, accents[0])
            for ((v, c) in items) {
                val d = GradientDrawable()
                d.shape = GradientDrawable.OVAL
                d.setColor(c)
                d.setStroke(dp(3), if (c == cur) Color.WHITE else 0x33FFFFFF)
                v.background = d
            }
        }
        for (c in accents) {
            val v = View(this)
            val lp = LinearLayout.LayoutParams(dp(40), dp(40))
            lp.rightMargin = dp(12)
            v.layoutParams = lp
            v.setOnClickListener {
                prefs.edit().putInt(Prefs.ACCENT, c).apply()
                car.scene.setAccent(c)
                refresh()
            }
            items.add(Pair(v, c))
            row.addView(v)
        }
        refresh()
        return row
    }

    private fun togglePanel() {
        panelVisible = !panelVisible
        panel.visibility = if (panelVisible) View.VISIBLE else View.GONE
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = if (panelVisible) {
            View.SYSTEM_UI_FLAG_VISIBLE
        } else {
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        }
        if (!panelVisible && !hintShown) {
            hintShown = true
            Toast.makeText(this, "Нажми на машину, чтобы вернуть настройки", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- Тестовый бит ----------

    private fun playTest() {
        Thread {
            try {
                val sr = 44100
                val secs = 6
                val n = sr * secs
                val data = ShortArray(n)
                var ph = 0.0
                var seed = 12345
                for (i in 0 until n) {
                    val t = i / sr.toDouble()
                    val tb = t % 0.5
                    val f = 48.0 + 110.0 * exp(-tb * 30.0)
                    ph += 2.0 * PI * f / sr
                    var v = sin(ph) * exp(-tb * 6.5) * 0.85
                    val th = (t + 0.25) % 0.5
                    seed = seed * 1103515245 + 12345
                    val noise = ((seed shr 16) and 0x7fff) / 16384.0 - 1.0
                    v += noise * exp(-th * 70.0) * 0.18
                    val bass = sin(2.0 * PI * 55.0 * t) * 0.18 * (if ((t % 2.0) < 1.0) 1.0 else 0.0)
                    data[i] = ((v + bass).coerceIn(-1.0, 1.0) * 30000).toInt().toShort()
                }
                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sr)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(n * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()
                track.write(data, 0, n)
                track.play()
                Thread.sleep(secs * 1000L + 300)
                track.release()
            } catch (e: Exception) {
            }
        }.start()
    }

    // ---------- Запуск и разрешения ----------

    private fun onStartClicked() {
        if (AudioBus.running) {
            stopService(Intent(this, AudioService::class.java))
            return
        }
        val need = ArrayList<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.RECORD_AUDIO)
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (need.isNotEmpty()) {
            requestPermissions(need.toTypedArray(), 1)
            return
        }
        beginCapture()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            beginCapture()
        } else {
            Toast.makeText(this, "Без доступа к звуку визуализация не работает", Toast.LENGTH_LONG).show()
        }
    }

    private fun beginCapture() {
        val method = prefs.getInt(Prefs.METHOD, 0)
        if (method == 1 && Build.VERSION.SDK_INT >= 29) {
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            @Suppress("DEPRECATION")
            startActivityForResult(mpm.createScreenCaptureIntent(), 2)
        } else {
            startAudioService(0, null)
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 2) {
            if (resultCode == RESULT_OK && data != null) {
                startAudioService(resultCode, data)
            } else {
                Toast.makeText(this, "Нужно разрешить запись звука", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun startAudioService(code: Int, data: Intent?) {
        val i = Intent(this, AudioService::class.java)
        i.putExtra("mode", if (data != null) 1 else 0)
        if (data != null) {
            i.putExtra("code", code)
            i.putExtra("data", data)
        }
        startForegroundService(i)
    }

    // ---------- Статус ----------

    private fun refreshStatus() {
        val running = AudioBus.running
        startBtn.text = if (running) "■  СТОП" else "▶  СТАРТ"
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        val err = AudioBus.error
        status.text = when {
            !running -> "Демо: машина качает сама. Нажми «Старт» — она заиграет под музыку из любого плеера."
            err != null -> err
            am.isMusicActive && System.currentTimeMillis() - AudioBus.lastSignal > 4000 ->
                "Музыка играет, но звук не приходит. Включи второй способ в разделе «Как слушать звук»."
            !am.isMusicActive -> "Слушаю. Запусти музыку в любом плеере."
            else -> "Работает ✓"
        }
    }

    override fun onResume() {
        super.onResume()
        handler.post(ticker)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }
}
