package com.musicviz.app

import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sqrt

/** Общая шина: сервис пишет сюда уровни звука, CarView читает. */
object AudioBus {
    const val BAND_COUNT = 28

    @Volatile var running = false
    @Volatile var bass = 0f
    @Volatile var mid = 0f
    @Volatile var high = 0f
    @Volatile var lastSignal = 0L
    @Volatile var error: String? = null
    val bands = FloatArray(BAND_COUNT)

    fun reset() {
        bass = 0f; mid = 0f; high = 0f
        for (i in bands.indices) bands[i] = 0f
    }
}

/** Превращает спектр (амплитуды по бинам) в уровни баса/середины/верха и полосы эквалайзера. */
class Analyzer {
    private var pBass = 0.06f
    private var pMid = 0.06f
    private var pHigh = 0.06f
    private var pAll = 0.06f
    private val n = AudioBus.BAND_COUNT
    private val tmp = FloatArray(n)
    private val edges = FloatArray(n + 1) { 40f * 350f.pow(it / n.toFloat()) }

    private fun band(m: FloatArray, binHz: Float, f1: Float, f2: Float): Float {
        val last = m.size - 1
        var a = (f1 / binHz).toInt()
        if (a < 1) a = 1
        if (a > last) return 0f
        var b = (f2 / binHz).toInt()
        if (b > last) b = last
        if (b < a) b = a
        var s = 0f
        for (k in a..b) s += m[k] * m[k]
        return sqrt(s / (b - a + 1))
    }

    fun push(m: FloatArray, binHz: Float) {
        val bass = band(m, binHz, 35f, 140f)
        val mid = band(m, binHz, 150f, 2000f)
        val high = band(m, binHz, 2000f, 12000f)

        if (bass + mid + high > 0.02f) AudioBus.lastSignal = System.currentTimeMillis()
        val silent = bass + mid + high < 0.004f

        pBass = max(pBass * 0.996f, bass).coerceAtLeast(0.06f)
        pMid = max(pMid * 0.996f, mid).coerceAtLeast(0.06f)
        pHigh = max(pHigh * 0.996f, high).coerceAtLeast(0.06f)

        AudioBus.bass = if (silent) 0f else (bass / pBass).coerceIn(0f, 1f).pow(1.4f)
        AudioBus.mid = if (silent) 0f else (mid / pMid).coerceIn(0f, 1f)
        AudioBus.high = if (silent) 0f else (high / pHigh).coerceIn(0f, 1f)

        var maxB = 0f
        for (i in 0 until n) {
            tmp[i] = band(m, binHz, edges[i], edges[i + 1]) * (1f + i * 0.06f)
            if (tmp[i] > maxB) maxB = tmp[i]
        }
        pAll = max(pAll * 0.997f, maxB).coerceAtLeast(0.06f)
        for (i in 0 until n) {
            AudioBus.bands[i] = if (silent) 0f else (tmp[i] / pAll).coerceIn(0f, 1f).pow(1.2f)
        }
    }
}

/** Простой FFT (radix-2). */
object Fft {
    fun transform(re: FloatArray, im: FloatArray) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while ((j and bit) != 0) {
                j = j xor bit
                bit = bit shr 1
            }
            j = j xor bit
            if (i < j) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var len = 2
        while (len <= n) {
            val ang = -2.0 * Math.PI / len
            val wlr = Math.cos(ang).toFloat()
            val wli = Math.sin(ang).toFloat()
            val half = len / 2
            var i = 0
            while (i < n) {
                var wr = 1f
                var wi = 0f
                for (k in 0 until half) {
                    val ur = re[i + k]
                    val ui = im[i + k]
                    val xr = re[i + k + half]
                    val xi = im[i + k + half]
                    val vr = xr * wr - xi * wi
                    val vi = xr * wi + xi * wr
                    re[i + k] = ur + vr
                    im[i + k] = ui + vi
                    re[i + k + half] = ur - vr
                    im[i + k + half] = ui - vi
                    val nwr = wr * wlr - wi * wli
                    wi = wr * wli + wi * wlr
                    wr = nwr
                }
                i += len
            }
            len = len shl 1
        }
    }
}
