package com.musicviz.engine;

/** 4x4 матрицы (row-major). */
final class Mat {
    static float[] id() { return new float[]{1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1}; }
    static float[] mul(float[] a, float[] b) {
        float[] r = new float[16];
        for (int i = 0; i < 4; i++)
            for (int j = 0; j < 4; j++) {
                float s = 0;
                for (int k = 0; k < 4; k++) s += a[i*4+k] * b[k*4+j];
                r[i*4+j] = s;
            }
        return r;
    }
    static float[] t(float x, float y, float z) { float[] m = id(); m[3]=x; m[7]=y; m[11]=z; return m; }
    static float[] s(float x, float y, float z) { float[] m = id(); m[0]=x; m[5]=y; m[10]=z; return m; }
    static float[] rx(float a) { float c=(float)Math.cos(a), s=(float)Math.sin(a); float[] m=id(); m[5]=c; m[6]=-s; m[9]=s; m[10]=c; return m; }
    static float[] ry(float a) { float c=(float)Math.cos(a), s=(float)Math.sin(a); float[] m=id(); m[0]=c; m[2]=s; m[8]=-s; m[10]=c; return m; }
    static float[] rz(float a) { float c=(float)Math.cos(a), s=(float)Math.sin(a); float[] m=id(); m[0]=c; m[1]=-s; m[4]=s; m[5]=c; return m; }
}
